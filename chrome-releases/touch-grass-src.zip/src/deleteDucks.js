function removeDucks() {
    $('.duck').remove();
}
$("#deletebtn").addEventListener("click", removeDucks());